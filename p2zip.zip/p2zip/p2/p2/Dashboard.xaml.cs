﻿using System.Linq;
using System.Windows;

namespace p2
{
    public partial class Dashboard : Window
    {
        private string username;

        public Dashboard(string username)
        {
            InitializeComponent();

            this.username = username;

            // Show logged-in username
            lblWelcome.Text = "Welcome, " + username;

            // Load dashboard data
            LoadDashboardData();
        }


        // =====================================================
        // LOAD DASHBOARD DATA
        // =====================================================

        private void LoadDashboardData()
        {
            // -----------------------------------------------
            // TOTAL BOOKS
            // -----------------------------------------------

            int totalBooks =
                LibraryData.Books.Sum(book => book.Quantity);

            txtTotalBooks.Text =
                totalBooks.ToString();


            // -----------------------------------------------
            // ISSUED BOOKS
            // -----------------------------------------------

            int issuedBooks =
                LibraryData.IssuedBooks.Count;

            txtIssuedBooks.Text =
                issuedBooks.ToString();


            // -----------------------------------------------
            // AVAILABLE BOOKS
            // -----------------------------------------------

            int availableBooks =
                LibraryData.Books.Sum(book => book.Available);

            txtAvailableBooks.Text =
                availableBooks.ToString();


            // -----------------------------------------------
            // MEMBERS
            // -----------------------------------------------

            // Currently using unique member names
            int members =
                LibraryData.IssuedBooks
                .Select(issue => issue.MemberName)
                .Distinct()
                .Count();

            txtMembers.Text =
                members.ToString();


            // -----------------------------------------------
            // RECENTLY ISSUED BOOKS
            // -----------------------------------------------

            RecentBooksGrid.ItemsSource = null;

            RecentBooksGrid.ItemsSource =
                LibraryData.IssuedBooks
                .AsEnumerable()
                .Reverse()
                .Take(10)
                .ToList();
        }


        // =====================================================
        // BOOKS
        // =====================================================

        private void Books_Click(object sender, RoutedEventArgs e)
        {
            BooksWindow booksWindow =
                new BooksWindow();

            booksWindow.ShowDialog();

            // Refresh dashboard
            LoadDashboardData();
        }


        // =====================================================
        // ISSUE BOOK
        // =====================================================

        private void IssueBook_Click(object sender, RoutedEventArgs e)
        {
            IssueBookWindow issueBookWindow =
                new IssueBookWindow();

            issueBookWindow.ShowDialog();

            // IMPORTANT:
            // Refresh dashboard after issuing a book

            LoadDashboardData();
        }


        // =====================================================
        // RETURN BOOK
        // =====================================================

        private void ReturnBook_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Return Book page will be added next.",
                "Return Book",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }


        // =====================================================
        // MEMBERS
        // =====================================================

        private void Members_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Members page will be added next.",
                "Members",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }


        // =====================================================
        // REPORTS
        // =====================================================

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Reports page will be added next.",
                "Reports",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }


        // =====================================================
        // SETTINGS
        // =====================================================

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Settings page will be added next.",
                "Settings",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }


        // =====================================================
        // LOGOUT
        // =====================================================

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result =
                MessageBox.Show(
                    "Are you sure you want to logout?",
                    "Logout",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MainWindow login =
                    new MainWindow();

                login.Show();

                this.Close();
            }
        }

        private void RecentBooksGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }
    }
}