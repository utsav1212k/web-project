﻿using System;
using System.Windows;

namespace p2
{
    public partial class IssueBookWindow : Window
    {
        public IssueBookWindow()
        {
            InitializeComponent();

            LoadBooks();

            LoadIssuedBooks();

            dpReturnDate.SelectedDate =
                DateTime.Today.AddDays(7);
        }

        // ================= LOAD BOOKS =================

        private void LoadBooks()
        {
            cmbBooks.ItemsSource = null;

            cmbBooks.ItemsSource =
                LibraryData.Books.FindAll(
                    book => book.Available > 0);
        }

        // ================= LOAD ISSUED BOOKS =================

        private void LoadIssuedBooks()
        {
            IssuedGrid.ItemsSource = null;

            IssuedGrid.ItemsSource =
                LibraryData.IssuedBooks;
        }

        // ================= ISSUE BOOK =================

        private void Issue_Click(object sender, RoutedEventArgs e)
        {
            Book selectedBook =
                cmbBooks.SelectedItem as Book;

            string memberName =
                txtMemberName.Text.Trim();

            if (selectedBook == null)
            {
                MessageBox.Show(
                    "Please select a book.",
                    "Issue Book",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            if (string.IsNullOrWhiteSpace(memberName))
            {
                MessageBox.Show(
                    "Please enter member name.",
                    "Issue Book",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                txtMemberName.Focus();

                return;
            }

            if (!dpReturnDate.SelectedDate.HasValue)
            {
                MessageBox.Show(
                    "Please select return date.",
                    "Issue Book",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            if (dpReturnDate.SelectedDate.Value <
                DateTime.Today)
            {
                MessageBox.Show(
                    "Return date cannot be in the past.",
                    "Issue Book",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            if (selectedBook.Available <= 0)
            {
                MessageBox.Show(
                    "This book is not available.",
                    "Issue Book",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // Decrease available quantity

            selectedBook.Available--;

            // Create issue record

            IssueRecord record = new IssueRecord();

            record.BookID = selectedBook.BookID;

            record.BookName = selectedBook.BookName;

            record.MemberName = memberName;

            record.IssueDate =
                DateTime.Today.ToString("dd/MM/yyyy");

            record.ReturnDate =
                dpReturnDate.SelectedDate.Value
                    .ToString("dd/MM/yyyy");

            LibraryData.IssuedBooks.Add(record);

            // Refresh

            LoadBooks();

            LoadIssuedBooks();

            // Clear fields

            txtMemberName.Clear();

            dpReturnDate.SelectedDate =
                DateTime.Today.AddDays(7);

            MessageBox.Show(
                "Book issued successfully!",
                "Success",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        // ================= CLOSE =================

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}