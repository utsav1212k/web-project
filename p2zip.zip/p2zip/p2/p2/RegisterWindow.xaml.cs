﻿using System.Windows;
using System.Windows.Media;

namespace p2
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Password;
            string confirmPassword = txtConfirmPassword.Password;

            // Username validation
            if (string.IsNullOrWhiteSpace(username))
            {
                ShowError("Please enter username.");
                txtUsername.Focus();
                return;
            }

            // Email validation
            if (string.IsNullOrWhiteSpace(email))
            {
                ShowError("Please enter email.");
                txtEmail.Focus();
                return;
            }

            // Simple email validation
            if (!email.Contains("@") || !email.Contains("."))
            {
                ShowError("Please enter a valid email.");
                txtEmail.Focus();
                return;
            }

            // Password validation
            if (string.IsNullOrWhiteSpace(password))
            {
                ShowError("Please enter password.");
                txtPassword.Focus();
                return;
            }

            // Password length
            if (password.Length < 4)
            {
                ShowError("Password must contain at least 4 characters.");
                txtPassword.Focus();
                return;
            }

            // Confirm password
            if (password != confirmPassword)
            {
                ShowError("Passwords do not match.");
                txtConfirmPassword.Focus();
                return;
            }

            // Save registered user
            MainWindow.RegisteredUsername = username;
            MainWindow.RegisteredEmail = email;
            MainWindow.RegisteredPassword = password;

            MessageBox.Show(
                "Registration successful!\n\nYou can now login.",
                "Registration Successful",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            // Close register page
            this.Close();
        }

        private void BackToLogin_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ShowError(string message)
        {
            lblMessage.Text = message;
            lblMessage.Foreground = Brushes.Red;
        }
    }
}