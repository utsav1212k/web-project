﻿namespace p2
{
    public class Book
    {
        public int BookID { get; set; }

        public string BookName { get; set; }

        public string Author { get; set; }

        public string Category { get; set; }

        public int Quantity { get; set; }

        public int Available { get; set; }

        public Book()
        {
        }

        public Book(
            int bookID,
            string bookName,
            string author,
            string category,
            int quantity)
        {
            BookID = bookID;
            BookName = bookName;
            Author = author;
            Category = category;
            Quantity = quantity;
            Available = quantity;
        }
    }
}