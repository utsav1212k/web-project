﻿using System.Windows;

namespace p2
{
    public partial class BooksWindow : Window
    {
        public BooksWindow()
        {
            InitializeComponent();

            LoadBooks();
        }

        private void LoadBooks()
        {
            BooksGrid.ItemsSource = null;
            BooksGrid.ItemsSource = LibraryData.Books;
        }

        // ================= ADD BOOK =================

        private void AddBook_Click(object sender, RoutedEventArgs e)
        {
            string bookName = txtBookName.Text.Trim();
            string author = txtAuthor.Text.Trim();
            string category = txtCategory.Text.Trim();

            int quantity;

            if (string.IsNullOrWhiteSpace(bookName))
            {
                MessageBox.Show("Please enter book name.");
                return;
            }

            if (string.IsNullOrWhiteSpace(author))
            {
                MessageBox.Show("Please enter author name.");
                return;
            }

            if (string.IsNullOrWhiteSpace(category))
            {
                MessageBox.Show("Please enter category.");
                return;
            }

            if (!int.TryParse(txtQuantity.Text, out quantity))
            {
                MessageBox.Show("Please enter a valid quantity.");
                return;
            }

            if (quantity <= 0)
            {
                MessageBox.Show("Quantity must be greater than 0.");
                return;
            }

            int newID = 1;

            if (LibraryData.Books.Count > 0)
            {
                newID = LibraryData.Books[
                    LibraryData.Books.Count - 1
                ].BookID + 1;
            }

            Book newBook = new Book(
                newID,
                bookName,
                author,
                category,
                quantity);

            LibraryData.Books.Add(newBook);

            LoadBooks();

            txtBookName.Clear();
            txtAuthor.Clear();
            txtCategory.Clear();
            txtQuantity.Clear();

            MessageBox.Show(
                "Book added successfully!",
                "Success",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        // ================= DELETE BOOK =================

        private void DeleteBook_Click(object sender, RoutedEventArgs e)
        {
            Book selectedBook =
                BooksGrid.SelectedItem as Book;

            if (selectedBook == null)
            {
                MessageBox.Show(
                    "Please select a book to delete.");
                return;
            }

            if (selectedBook.Quantity != selectedBook.Available)
            {
                MessageBox.Show(
                    "This book cannot be deleted because it is currently issued.");
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                "Delete " + selectedBook.BookName + "?",
                "Delete Book",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                LibraryData.Books.Remove(selectedBook);

                LoadBooks();

                MessageBox.Show(
                    "Book deleted successfully.",
                    "Success",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }

        // ================= CLOSE =================

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}