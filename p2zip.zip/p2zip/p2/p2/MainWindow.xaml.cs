﻿using System.Windows;
using System.Windows.Media;

namespace p2
{
    public partial class MainWindow : Window
    {
        // Registered user information
        public static string RegisteredUsername = "";
        public static string RegisteredEmail = "";
        public static string RegisteredPassword = "";

        public MainWindow()
        {
            InitializeComponent();
        }

        // ================= LOGIN =================

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Password;

            // Check username
            if (string.IsNullOrWhiteSpace(username))
            {
                ShowError("Please enter username.");
                txtUsername.Focus();
                return;
            }

            // Check password
            if (string.IsNullOrWhiteSpace(password))
            {
                ShowError("Please enter password.");
                txtPassword.Focus();
                return;
            }

            // Check registered account
            if (username == RegisteredUsername &&
                password == RegisteredPassword &&
                RegisteredUsername != "")
            {
                // Open Dashboard
                Dashboard dashboard = new Dashboard(username);

                dashboard.Show();

                // Close Login Window
                this.Close();
            }
            else
            {
                ShowError("Invalid username or password.");
            }
        }

        // ================= REGISTER =================

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            // Open Register Window
            RegisterWindow registerWindow = new RegisterWindow();

            // Make login the owner
            registerWindow.Owner = this;

            // Hide login page
            this.Hide();

            // Show Register page
            registerWindow.ShowDialog();

            // Show login page again
            this.Show();

            // Clear login fields
            txtUsername.Clear();
            txtPassword.Clear();

            // Clear message
            lblMessage.Text = "";
        }

        // ================= ERROR MESSAGE =================

        private void ShowError(string message)
        {
            lblMessage.Text = message;
            lblMessage.Foreground = Brushes.Red;
        }
    }
}