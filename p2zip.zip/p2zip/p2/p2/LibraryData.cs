﻿using System.Collections.Generic;

namespace p2
{
    public static class LibraryData
    {
        public static List<Book> Books { get; set; } =
            new List<Book>();

        public static List<IssueRecord> IssuedBooks { get; set; } =
            new List<IssueRecord>();

        static LibraryData()
        {
            Books.Add(
                new Book(
                    1,
                    "C# Programming",
                    "John Smith",
                    "Programming",
                    5));

            Books.Add(
                new Book(
                    2,
                    "Data Structures",
                    "Mark Allen",
                    "Computer Science",
                    4));

            Books.Add(
                new Book(
                    3,
                    "Operating Systems",
                    "Abraham Silberschatz",
                    "Computer Science",
                    3));

            Books.Add(
                new Book(
                    4,
                    "Web Development",
                    "Robert Smith",
                    "Web Technology",
                    6));
        }
    }


    public class IssueRecord
    {
        public int BookID { get; set; }

        public string BookName { get; set; }

        public string MemberName { get; set; }

        public string IssueDate { get; set; }

        public string ReturnDate { get; set; }
    }
}